import { CtxOrReq } from "next-auth/client/_utils";
import { getCsrfToken, signIn } from "next-auth/react";
import { useState } from "react";

interface LoginProps {
  csrfToken: string;
}

export default function Login({ csrfToken }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Utiliza o provider "credentials" para autenticar o usuário
    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    if (res?.error) {
      setError(res.error);
    } else {
      // Redireciona para a página protegida, como /dashboard, se o login for bem-sucedido
      window.location.href = "/dashboard";
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="max-w-md w-full bg-white p-8 rounded shadow">
        <h2 className="text-2xl font-bold mb-6 text-center">Login</h2>
        {error && <div className="mb-4 text-red-500">{error}</div>}
        <form onSubmit={handleSubmit}>
          {/* Campo oculto para o csrfToken */}
          <input
            name="csrfToken"
            type="hidden"
            defaultValue={csrfToken}
          />
          <div className="mb-4">
            <label className="block text-gray-700">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 border rounded"
              placeholder="email@exemplo.com"
              required
            />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 border rounded"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
          >
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
}

// Busca o csrfToken no servidor para incluir no formulário
export async function getServerSideProps(context: CtxOrReq | undefined) {
  const csrfToken = (await getCsrfToken(context)) ?? null;
  return {
    props: {
      csrfToken,
    },
  };
}
